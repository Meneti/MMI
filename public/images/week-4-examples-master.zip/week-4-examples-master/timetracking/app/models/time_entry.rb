class TimeEntry < ApplicationRecord
  belongs_to :project
end

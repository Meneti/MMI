class StaticPagesController < ApplicationController
  def home
    render :home
  end
end
